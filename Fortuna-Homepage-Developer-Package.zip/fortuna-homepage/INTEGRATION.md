# GitHub / Vercel / Next.js integration — approved cream layout

The owner confirmed GitHub and Vercel. Public HTML confirms a Next.js application (`/_next/static/`, Next image optimizer, React payloads and Turbopack-named client chunks). Exact Next.js version, repository, branch, package manager, hosting settings and server implementation were not accessible. This package is an additive frontend handoff, not a repository patch.

## Evidence and existing routes

- Homepage: https://www.fortunaglobalholdings.com/
- Public login: https://www.fortunaglobalholdings.com/auth/login
- Existing legal links: `/privacy-policy`, `/terms-and-conditions`.
- Existing client bundle submits JSON to `/api/request-access` using POST.
- Observed form fields: firstName, lastName, referralSource, phoneCountryIso2, mobileNumber, email, city, timezone, bestContactTimes, occupationOrBusiness, platformInterest, preferredContactMethod.

Do not infer backend validation or authorization from this public evidence. No endpoint was submitted to, and no login was attempted. Browser indexing redirected terms to login and could not fetch privacy; legal page contents and current authorization behavior remain unverified. Keep their existing files and access rules exactly as they are.

## Apply in the existing repository

1. Make a feature branch from the current project. Do not overwrite the repository or substitute a new Vercel project. Inspect current app router/page router, homepage, layout, request-access dialog, authentication middleware/proxy and server handlers.
2. Copy package `assets/` to `public/fortuna/`. Copy `nextjs/FortunaHomepage.tsx` and `nextjs/fortuna.css` into the existing components directory. No new dependencies are required. If the project's Next.js convention requires global CSS imports in a root layout or pages/_app, move the CSS import there. Integrated design rules are scoped to `.fortuna-site`, and font-face family names use Fortuna aliases; the integrated sheet excludes static preview dialog and global body resets.
3. Replace only the public homepage presentation with the component. Retain current metadata, providers and existing server logic. Keep `noindex` on previews; the static file's noindex is intentional and must not be carried into production metadata.
4. Wire `onRequestAccess` to the ORIGINAL dialog's open state or trigger. Render that existing dialog alongside the homepage. Keep its steps, field validation, consent text, success/error states, submission behavior and POST endpoint. Do not build an insecure replacement form from the observed field list.
5. `nextjs/HomepageIntegration.tsx` provides a typed wrapper accepting your actual existing dialog as `AccessDialog`. Its adapter interface is `{open, onOpenChange}`. If your original uses different props, write a thin adapter and retain its internals. The following illustrates the same connection pattern, NOT a drop-in import for an unseen repo:

```tsx
'use client';
import { useState } from 'react';
import FortunaHomepage from './FortunaHomepage';
// Import the actual existing controlled dialog from this repository.
export default function PublicHome() {
  const [open, setOpen] = useState(false);
  return <>
    <FortunaHomepage onRequestAccess={() => setOpen(true)} />
    {/* Render ORIGINAL dialog with its actual open/onOpenChange props here. */}
  </>;
}
```

The dialog's exported component name and props must be inspected in the real repository. If it is trigger-based, adapt the existing trigger rather than recreating the API. Do not ship the commented pattern without a functioning dialog. Until wired, the component falls back to the existing live homepage. This deliberate fallback is useful for isolated previews but would loop on the deployed homepage; binding the callback is a release requirement.

6. Existing legal and login links are absolute URLs to preserve destinations in the downloadable preview. Once integrated on the same domain, change them to `/privacy-policy`, `/terms-and-conditions`, `/auth/login` so previews test the correct environment. Preserve any existing auth return-to parameter and redirect behavior discovered in the repo.
7. Keep all API handlers, database models, sessions, cookies, email/CRM integrations, middleware, protected route groups, rate limits, secrets, robots/canonical rules and legal content. Do not alter Vercel environment variables or route rewrites for this visual change. Do not move protected routes beneath a public-only layout accidentally.
8. Build using the repository's existing scripts/lockfile and create a Vercel preview using its normal GitHub workflow. Preview creation and production deployment were not performed as part of this delivery. Confirm which branch auto-deploys to production before pushing anything.
9. Perform the staging checklist in VALIDATION.md, compare against the original mockup and obtain visual approval. Roll back by reverting the presentation commit if necessary, preserving backend and legal history.

Keep `assets/fonts/*-OFL.txt` with distributed font files. Font/background paths in the integrated CSS already point to `/fortuna/`; the standalone preview uses relative `assets/` paths. Do not include static app.js or its preview dialog when using the React component.

No vercel.json, package lockfile or new app scaffold is supplied, intentionally: replacing those without inspecting the real repo could damage the existing functionality.
