# Verification and release checklist

## Completed on 14 October 2026

- Served standalone files locally and received HTTP 200.
- Inspected the page in the in-app browser against the supplied cream-and-gold reference.
- Checked rendered viewport widths 320, 390, approximately 731 and 1440 CSS pixels. Final measured document widths matched viewport widths; no horizontal overflow. A mobile icon-row overflow was corrected and rechecked.
- Checked desktop section copy bounds; no heading/paragraph extended below its section at the inspected desktop widths.
- Local font loading completed. Browser captured no warnings or errors.
- Mobile menu expands, anchor selection navigates to the target section and closes the menu.
- Request Access opens the explicit local-preview notice; Escape closes it. No application or login was submitted.
- JavaScript syntax check passed.
- Both TSX files transpiled without syntax diagnostics using TypeScript 5.9.3. This was a standalone syntax check, not a project type-check or Next.js production build.
- HTML has one H1, unique IDs and valid local anchor targets. All referenced local assets exist; inline SVG parses; CSS blocks are balanced. Next.js stylesheet contains no standalone body reset or preview dialog styles.
- Original uploaded reference is retained unchanged. Active artwork plate was visually inspected: no embedded marketing copy, navigation, logo or icons remain. Globe is text-free; page wording is live HTML.

## Limits of verification

The private GitHub repository and Vercel project were not connected. No repository build, authentication regression test, API request, legal-page content audit or deployment was performed. The static preview does not reproduce private access functionality; the integration hooks retain and reuse the project's original implementation. Existing legal links remain pointed at the original domain until the developer changes them to environment-relative URLs during integration.

The exact original font and separate logo master were not available. Font substitutes and a logo viewport crop are documented. The background plate is an AI recreation from a flattened image, with possible small differences, and is limited to 1024px source width. Pixel-perfect fidelity and high-density photographic quality require original production assets. Mobile layout is an interpretation because only a desktop mockup was provided.

## Required checks in the real project before release

1. Follow INTEGRATION.md on a feature branch; inspect the actual Next.js structure and original request dialog first. Keep all existing middleware/proxy, API handlers, auth providers, secrets, route protection and legal pages.
2. Wire all Request Access controls to the original dialog. Verify its existing steps, validation, consent, error and success states with approved test data in staging. Confirm `/api/request-access` behavior, server validation, rate limits and email/CRM behavior remain unchanged. The isolated live-homepage fallback must not be used on the final production homepage because it would loop back to itself.
3. Verify private sign-in, sign-out, forgotten password, authorized and unauthorized access, sessions and any return-to redirects using the existing supported test accounts. Do not expose protected data in client HTML.
4. Keep `/privacy-policy` and `/terms-and-conditions` content, routes and access rules intact. Test links in the correct staging environment. If the current legal pages redirect to sign-in, investigate with the site owner; do not silently alter their rules.
5. Run the repository's existing build/type checks. Verify keyboard tab order, focus visibility, screen-reader landmarks, menu, dialog focus management, zoom and reduced-motion behavior. Check Safari/iOS, Chrome and Firefox at 320/390/768/1024/1440px and with 200% text zoom; CSS container-unit support is required.
6. Compare the final page with assets/approved-reference.png. Obtain the separate white-background logo master and higher-resolution artwork if required. Recheck line breaks after changing fonts or images. Review bronze text contrast against the final artwork at each size.
7. Keep previews noindex. Restore the repository's approved production SEO metadata/canonical rules when releasing. The standalone preview intentionally includes noindex and is not a replacement for the app's existing SEO setup.
8. Confirm the GitHub production branch and Vercel deployment rules before pushing. Use the existing deployment pipeline; keep a revertable presentation commit. No production deployment is included in this handoff.
