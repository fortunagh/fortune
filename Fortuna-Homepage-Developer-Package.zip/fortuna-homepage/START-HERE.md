# Fortuna Global Holdings — approved-layout implementation

Prepared 14 October 2026. This package supersedes the earlier dark reconstruction. No live website, GitHub repository or Vercel settings have been changed.

## Preview

Open `index.html` in a browser, or serve this folder with a local static server (`python3 -m http.server 8766`) and visit http://localhost:8766. No dependency install or external font service is needed. The page includes desktop, tablet and mobile layouts.

## Developer files

- `index.html`, `styles.css`, `app.js`: working standalone implementation.
- `nextjs/FortunaHomepage.tsx`, `nextjs/fortuna.css`: React/Next.js implementation of the same page.
- `nextjs/HomepageIntegration.tsx`: typed connection wrapper for the existing request-access dialog.
- `assets/approved-reference.png`: the user-provided approved 1024×1536 mockup, unchanged.
- `assets/artwork-plate.png`: clean text-free artwork layer recreated from that image.
- `assets/fonts/`: locally hosted open-source font substitutes and their SIL Open Font Licences.
- `INTEGRATION.md`: GitHub/Vercel integration and preservation instructions.
- `DESIGN-AND-ASSETS.md`: layout, typography, graphics, provenance and reproduction limits.
- `COPY.md`: complete approved wording in editable text.
- `VALIDATION.md`: verification performed and required repository/staging checks.

## Match to your design

The desktop page uses the uploaded mockup's composition: logo and four navigation items, open vault hero, Our Belief and text-free black/gold globe, enlarged “NOT EVERYTHING IS BUILT FOR EVERYONE” opposite “Neither is Fortuna,” Identify / Align / Create, gold armillary, Our Purpose and the Private Consideration / Limited Availability CTA. All copy was transcribed from the uploaded design; the previous website's different marketing copy has been removed.

The logo is a CSS viewport crop of the exact logo visible in the supplied approved image. This avoids substituting the earlier logo. It is a raster crop from a flattened mockup, not a recovered original white-background logo master. The developer should substitute the user's separate high-resolution logo master when available.

The mockup is a flattened image. The photographic artwork was recreated as a text-free background plate using the built-in image tool; it is not the original layered render or 3D source. Fonts are close open-source substitutes, not a verified identification. Rendering and wrapping therefore differ slightly. The responsive mobile arrangement is newly implemented because the supplied design shows only desktop. The integrated footer adds existing legal links and private sign-in so they remain discoverable.

## Access functionality

The standalone preview opens an explicit notice and directs users to the current live site; it does not accept applications. The Next.js component must be connected to the existing application's original request-access dialog using the provided callback/wrapper. Keep the real dialog and backend intact. No credentials, submission handlers, authentication, database or legal page content were copied or replaced. Binding and validating the original dialog in the actual repository is required before production release.

No deployment has been performed. Use this as a developer handoff and staging implementation.
