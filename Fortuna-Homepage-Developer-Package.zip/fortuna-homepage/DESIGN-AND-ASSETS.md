# Design specifications and asset manifest

## Reference and fidelity

The sole visual/copy source is the user-uploaded `Fortuna Global Holdings_ Infinite Abundance.png` (1024×1536), now bundled unchanged as `assets/approved-reference.png`. This is a website layout reference, not a slide deck. The earlier dark implementation is superseded and is not part of this package.

All visible headings, paragraphs, navigation, buttons and approach icons are HTML/SVG. The photographic scenes use a text-free raster background plate, allowing normal text selection, responsive font sizing and editing. The logo is displayed by a CSS viewport crop of the source logo because the separate original logo file has not been supplied in this chat. Its visible design matches the uploaded layout; its quality is limited by the mockup's resolution.

`artwork-plate.png` was recreated using the built-in image-generation tool from the uploaded reference. Text, logo, navigation, buttons, divider rules and approach icons were removed while preserving the vault, city skyline, globe, doorway, armillary and section boundaries. Close visual comparison shows the intended scene placements are retained. Small photographic details can differ; this is not an original layered/source asset. Final production asset sign-off belongs against the uploaded reference. The globe contains no text; it retains the reference's dark sphere, gold continents and limited highlights.

## Assets and rights

| Asset | Status / usage |
|---|---|
| approved-reference.png | User-provided original; used as reference and CSS crop for logo only. No raster modification. |
| artwork-plate.png | AI-edited/recreated photographic background, active across hero, belief, collective and purpose sections. Prompt below. |
| Inline approach SVGs | Newly authored vectors matching compass, alignment rings and triangular possibility icon in reference. No icon library. |
| bodoni-400.ttf / bodoni-500.ttf | Open-source Bodoni Moda, served locally as “Fortuna Bodoni.” Substitute for unidentified reference display font. |
| cormorant-400.ttf / cormorant-italic-400.ttf | Open-source Cormorant Garamond, served locally as “Fortuna Garamond.” Substitute for body/italic text. |
| *-OFL.txt | Font licences retained for distribution. |

Font files were downloaded from Google Fonts' CSS/font endpoints; licences from https://github.com/google/fonts/tree/main/ofl/bodonimoda and https://github.com/google/fonts/tree/main/ofl/cormorantgaramond. Fonts are not extracted from the flattened mockup. Arial/Helvetica are local system fallbacks for navigation and labels, not bundled proprietary font files.

The user should confirm rights to the supplied branding and source artwork before publication. No commercial stock image or paid font has been acquired. Exact original renders, 3D scenes, a vector logo master and exact commercial fonts cannot be recovered from this flattened image. If an original font is later identified, obtain an appropriate web embedding licence and recheck line breaks.

## Desktop geometry

The page uses a 1536px maximum width and a CSS size container. One `cqw` equals 1% of the page width. The source art uses a 1024×1536 atlas mapped to `background-size: 100cqw 150cqw`. Each scene displays its corresponding section by changing the vertical background offset.

| Section | Approximate source start | Height at 1024px page width |
|---|---:|---:|
| Hero (header overlays it) | 0px | 445px |
| Our Belief | 445px | 326px |
| The Collective | 771px | 263px |
| Our Approach | 1034px | 186px (slightly taller for font wrapping) |
| Purpose / Access CTA | 1210px | 326px |

Section backgrounds are positioned independently, so the slightly taller approach block does not shift the source artwork alignment. Main copy begins around 7.5–8% from the left. Globe fills the right side of Our Belief; doorway/statement fills the left of The Collective; armillary fills the left of Our Purpose. Footer is an integration addition beneath the supplied mockup.

Colours: cream #f5f1ea; ink #101217; bronze #a84d0b. Hero display ~7.05cqw; section titles ~3.25–3.5cqw; body ~1.7–1.97cqw; navigation ~0.88cqw; labels ~1.17cqw. Main body uses Cormorant Garamond 400; display Bodoni Moda 400/500; emphasis Cormorant Garamond italic. Statement uses gold #e9a544 and white, uppercase, 3.5cqw with tight line spacing. All values are editable in styles.css.

## Responsive behaviour

At 700px and below, the menu becomes a native keyboard-operable disclosure. Copy and photographic scene windows stack; headings/body use readable mobile sizes rather than shrinking the desktop screenshot. Vault, globe, doorway and armillary backgrounds are repositioned to show the focal subjects. The approach icons remain a three-column row. 370px adds a smaller logo crop. The 320px minimum is supported. Wider desktop typography scales to match the original composition. No JavaScript is needed for basic text rendering or anchor navigation; JavaScript sets the initial menu state and preview access notice.

Artwork windows use the shared plate and CSS background positions. Replacing the plate with a differently arranged image requires updating those offsets. For independently art-directed mobile photography, obtain separate source renders or export approved crops and replace the backgrounds. The supplied plate is 1024px wide; at 1536px it is upscaled and is not a retina-quality source. Obtain 2×/3× originals for premium large-screen delivery; a flattened image cannot add genuine detail.

## Logo substitution

`.logo` uses background-image approved-reference.png with a fixed proportional crop. Once the white-background logo master is available, replace this with an `<img>` (alt “Fortuna Global Holdings — Building Infinite Abundance”), remove its crop-related CSS and give the real asset its aspect ratio, width and height. Do not rebuild the brand lettering as HTML. Both static and Next.js versions need the same update.

## Generation record

Built-in image-generation tool, edit mode. No CLI/API-key fallback used. Final prompt:

“Edit target: supplied 1024x1536 Fortuna homepage image. Create a clean BACKGROUND ARTWORK PLATE with EXACT SAME 2:3 dimensions, composition, positions, scale and section boundaries. Remove ALL lettering, words, paragraphs, buttons, lines used as typography dividers, logos, navigation AND the three small approach icons from the entire image, replacing them seamlessly with matching cream marble or existing architecture. Preserve all photographic artwork exactly: hero gold open vault and Dubai skyline on right in top 0-445 px; black/gold globe on right at y445-771; dark doorway/city left at y771-1034; cream blank strip y1034-1210; gold armillary left and marble floor y1210-1536. Preserve the original clean light cream background behind all removed type. The black globe must remain dark with gold details and NO text. Do not change section heights, do not redesign, do not add objects. All text will be HTML later. No text anywhere, no brand mark, no icons. Output a full-height image aligned to original layout.”
