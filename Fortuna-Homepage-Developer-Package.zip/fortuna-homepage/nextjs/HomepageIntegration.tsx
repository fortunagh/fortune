"use client";
import { useState, type ComponentType } from "react";
import FortunaHomepage from "./FortunaHomepage";
/** Adapt your EXISTING request dialog to this small interface in the real repository. */
export type AccessDialogAdapterProps = { open: boolean; onOpenChange: (open: boolean) => void };
export default function HomepageIntegration({ AccessDialog }: { AccessDialog: ComponentType<AccessDialogAdapterProps> }) {
  const [open, setOpen] = useState(false);
  return <>
    <FortunaHomepage onRequestAccess={() => setOpen(true)} />
    <AccessDialog open={open} onOpenChange={setOpen} />
  </>;
}
