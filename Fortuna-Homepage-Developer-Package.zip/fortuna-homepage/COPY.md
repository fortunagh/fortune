# Homepage copy — transcribed from the supplied approved image

## Header

Fortuna Global Holdings
Building Infinite Abundance

Our Approach · Opportunities · The Collective · Request Access

## Hero

BUILDING
INFINITE ABUNDANCE

OPPORTUNITY IS THE VEHICLE.
ABUNDANCE IS THE VISION.
IMPACT IS THE LEGACY.

PEOPLE
CAPITAL
CAPABILITY
STRUCTURE
SYSTEMS
RELATIONSHIPS
OPPORTUNITY

## Our Belief

Extraordinary outcomes
begin with alignment.

We don’t simply seek opportunity. We seek alignment — between exceptional people and exceptional opportunities.

Fortuna identifies and pursues opportunities with the potential to create meaningful value and lasting abundance, bringing together the right people, capital, capability, structure, systems and relationships to turn possibility into reality.

## The Collective

NOT EVERYTHING IS BUILT FOR EVERYONE.

Neither is Fortuna.

We are a select collective of entrepreneurial, business-minded individuals who think differently, contribute meaningfully and are driven to grow, evolve and create.

The value of the collective is not defined by how many people are part of it. It is defined by who they are.

## Our Approach

Identify. Align. Create.

We look beyond what already exists to what could exist — identifying opportunities with the potential to create abundance, and aligning the people, resources and strategies required to bring them to life.

IDENTIFY OPPORTUNITY
CREATE ALIGNMENT
UNLOCK POSSIBILITY

## Our Purpose

Opportunity creates abundance.
Abundance creates possibility.
Possibility creates impact.

## Access

ACCESS IS SELECTIVE

If this resonates,
the conversation begins here.

PRIVATE CONSIDERATION
LIMITED AVAILABILITY

REQUEST ACCESS

## Integration footer (additional to the image)

Privacy policy · Terms & conditions · Private sign in
© Fortuna Global Holdings 2026

Footer links retain the existing legal and sign-in destinations. The current site's existing full footer can instead be retained if required by its project architecture.
