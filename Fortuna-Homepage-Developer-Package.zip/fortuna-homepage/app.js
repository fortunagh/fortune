const mobile = matchMedia('(max-width: 700px)');
const menu = document.querySelector('.navigation');
function syncMenu(){ menu.open = !mobile.matches; }
syncMenu(); mobile.addEventListener('change', syncMenu);
document.querySelectorAll('.navigation a').forEach(a=>a.addEventListener('click',()=>{if(mobile.matches)menu.open=false;}));
document.querySelectorAll('[data-request-access]').forEach(a=>a.addEventListener('click',event=>{const dialog=document.querySelector('#access-notice');if(typeof dialog.showModal==='function'&&!event.metaKey&&!event.ctrlKey){event.preventDefault();dialog.showModal();}}));
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&mobile.matches)menu.open=false;});
